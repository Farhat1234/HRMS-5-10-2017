﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeePassport : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.Passport Pass;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.Passport Pass;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            Pass = new HRMDAL.Entites.Passport();

            bool value = Proxy.GetEmpPassportById(Convert.ToInt32(Request.QueryString["EmpId"]));

            if (value && !IsPostBack)
            {
                DataSet ds = Proxy.GetEmployeePassport(Convert.ToInt32(Request.QueryString["EmpId"]));
                grdEmpPassport.DataSource = ds;
                grdEmpPassport.DataBind();
                grdEmpPassport.Visible = true;
                pnlEmpPassport.Visible = false;
                btnAddNew.Visible = true;
            }
            else
            {
                // do nothing
            }
            if (!IsPostBack)
            {
                drpPassprtIssueCountry.DataSource = Proxy.CountryList();
                drpPassprtIssueCountry.DataTextField = "CountryName";
                drpPassprtIssueCountry.DataValueField = "CountryName";
                ListItem country = new ListItem();
                country.Text = "--- Select Country ---";
                country.Value = "-1";
                drpPassprtIssueCountry.AppendDataBoundItems = true;
                drpPassprtIssueCountry.Items.Add(country);
                drpPassprtIssueCountry.DataBind();

                ddlNationality.DataSource = Proxy.GetNationality();
                ddlNationality.DataTextField = "NationalityType";
                ddlNationality.DataValueField = "NationalityType";
                ListItem nationality = new ListItem();
                nationality.Text = "--- Select Nationality ---";
                nationality.Value = "-1";
                ddlNationality.AppendDataBoundItems = true;
                ddlNationality.Items.Add(nationality);
                ddlNationality.DataBind();
            }            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Pass.EmpID = Convert.ToInt32(Request.QueryString["EmpId"]);
                Pass.Name = txtName.Text;
                Pass.GivenName = txtGivenName.Text;
                Pass.IssueDate = Convert.ToDateTime(txtIssuedate.Text);
                Pass.PassportFor = drpPassportFor.SelectedItem.Text;
                Pass.Surname = txtSname.Text;
                Pass.DateofBirth = Convert.ToDateTime(txtDOB.Text);
                Pass.ExpiryDate = Convert.ToDateTime(txtExprdate.Text);
                Pass.Nationality = ddlNationality.SelectedItem.Text;
                Pass.PassportIssuingCountry = drpPassprtIssueCountry.SelectedItem.Text;
                Pass.PlaceofBirth = txtPOB.Text;
                Pass.PassportNo = Convert.ToInt32(Request.QueryString["txtPassNo"]);
                Pass.PlaceofIssue = txtPOI.Text;
                Pass.Gender = drpGender.SelectedItem.Text;
                Pass.RenewalApplied = drpRenewal.SelectedItem.Text;
                Proxy.AddPassport(Pass);

                DataSet ds = Proxy.GetEmployeePassport(Convert.ToInt32(Request.QueryString["EmpId"]));
                grdEmpPassport.DataSource = ds;
                grdEmpPassport.DataBind();
                grdEmpPassport.Visible = true;
                pnlEmpPassport.Visible = false;
                btnAddNew.Visible = true;
                btnSubmit.Visible = false;

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);

            }
            catch (Exception ex)
            {                
                throw ex;
            }            
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            grdEmpPassport.Visible = false;
            pnlEmpPassport.Visible = true;
            btnSubmit.Visible = true;
            btnAddNew.Visible = false;
        }
    }
}