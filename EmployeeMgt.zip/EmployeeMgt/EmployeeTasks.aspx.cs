﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeeTasks : System.Web.UI.Page
    {
        HRMBAL.BALService Proxy;
        HRMDAL.Entites.Tasks task;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            task = new HRMDAL.Entites.Tasks();

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                task.EmpId = Convert.ToInt32(Request.QueryString["EmpId"]);
                task.TaskOwner=ddlTaskOwner.SelectedItem.Text;
                task.TaskName=txtTaskName.Text;
                task.Description=txtDescription.Text;
                task.Priority=ddlPriority.SelectedItem.Text;
                task.StartDate=Convert.ToDateTime(txtStartDate.Text);
                task.EndDate=Convert.ToDateTime(txtEndDate.Text);
                task.Remainder=Convert.ToDateTime(txtRemainder.Text);
                task.Status=ddlStatus.SelectedItem.Text;
                Proxy.AddTask(task);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Task Created Successfully')", true);
                ClearFields();
            }
            catch 
            {                
                throw;
            }
        }

        public void ClearFields()
        {
            txtRemainder.Text=string.Empty;
            txtStartDate.Text=string.Empty;
            txtEndDate.Text=string.Empty;
            txtDescription.Text=string.Empty;
            ddlTaskOwner.Text=string.Empty;
            txtTaskName.Text=string.Empty;
            ddlStatus.SelectedValue = "-1";
            ddlPriority.SelectedValue = "-1";
            ddlTaskOwner.SelectedValue = "-1";
        }
    }
}