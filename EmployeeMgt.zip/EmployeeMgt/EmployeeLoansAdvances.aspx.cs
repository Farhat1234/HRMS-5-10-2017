﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeeLoansAdvances : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.LoanDetails loanDetails;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.LoanDetails loanDetails;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            loanDetails = new HRMDAL.Entites.LoanDetails();

            drpLpanAdvance.DataSource = Proxy.GetLoanTypes();
            drpLpanAdvance.DataTextField = "LoanType";
            drpLpanAdvance.DataValueField = "LoanID";
            ListItem loantype = new ListItem();
            loantype.Text = "--- Select Loan Type ---";
            loantype.Value = "-1";
            drpLpanAdvance.AppendDataBoundItems = true;
            drpLpanAdvance.Items.Add(loantype);
            drpLpanAdvance.DataBind();

            drpPA.DataSource = Proxy.GetReportingManagers();
            drpPA.DataTextField = "EmpName";
            drpPA.DataValueField = "EmpName";
            ListItem l = new ListItem();
            l.Text = "--- Select Primary Approver ---";
            l.Value = "-1";
            drpPA.AppendDataBoundItems = true;
            drpPA.Items.Add(l);
            drpPA.DataBind();

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                loanDetails.EmpID = Convert.ToInt32(Request.QueryString["EmpId"]);
                loanDetails.LoanTypeId = Convert.ToInt32(drpLpanAdvance.SelectedValue);
                loanDetails.PayeeName = txtPayeeName.Text;
                loanDetails.PrimaryApprover = drpPA.SelectedItem.Text;
                loanDetails.Amount = Convert.ToInt32(txtAmountRequested.Text);
                loanDetails.Note = txtNote.Text;
                Proxy.LoanDetails(loanDetails);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Request Initiated Successfully')", true);
                ClearFields();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ClearFields()
        {
            txtAmountRequested.Text = string.Empty;
            txtNote.Text = string.Empty;
            txtPayeeName.Text = string.Empty;
            drpLpanAdvance.SelectedValue = "-1";
            drpPA.SelectedValue = "-1";
        }
    }
}