﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HRMWcfService1.Utilities;


namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeeBankDetails : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.BankDetails Bank;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.BankDetails Bank;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            Bank = new HRMDAL.Entites.BankDetails();

            bool value = Proxy.GetBankDetailsById(Convert.ToInt32(Request.QueryString["EmpId"]));

            if (value && !IsPostBack)
            {
                DataSet ds = Proxy.GetBankById(Convert.ToInt32(Request.QueryString["EmpId"]));
                grdSavings.DataSource = ds;
                grdSavings.DataBind();             

                DataSet rds = Proxy.GetReimburseBankById(Convert.ToInt32(Request.QueryString["EmpId"]));
                grdReimburse.DataSource = rds;
                grdReimburse.DataBind();

                grdSavings.Visible = true;
                grdReimburse.Visible = true;
                pnlForm.Visible = false;
                btnAddNewBank.Visible = true;
                btnSubmit.Visible = false;
                ltrReminburse.Visible = true;
                ltrSavings.Visible = true;
            }
            else
            {
                // do nothing
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Bank.EmpId = Convert.ToInt32(Request.QueryString["EmpId"]);
                Bank.AccountType = txtAccType.Text;
                Bank.AccountNo = Convert.ToInt64(txtAccNo.Text);
                Bank.AccountHolderName = txtAccHolder.Text;
                Bank.BankName = txtBankName.Text;
                Bank.Branch = txtBranch.Text;
                Bank.Country = txtSCountry.Text;
                Bank.IFSC = txtSIFSC.Text;
                Bank.RAccountType = txtRAccType.Text;
                Bank.ReimburseAccHolder = txtRAccHolder.Text;
                Bank.RAccountNo = Convert.ToInt64(txtRAccNo.Text);
                Bank.RBankName = txtRBankName.Text;
                Bank.ReimburseBranch = txtRBranch.Text;
                Bank.RCountry = txtRCountry.Text;
                Bank.RIFSC = txtRIFSC.Text;
                Proxy.AddBankDetails(Bank);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
                Clear();
                pnlForm.Visible = false;
                btnSubmit.Visible = false;
                btnUpdate.Visible = true;
                grdSavings.Visible = true;
                
            }
            catch (Exception ex)
            {                
                throw ex;
            }            
        }

        public void Clear()
        {
            txtAccNo.Text = "";
            txtBankName.Text = "";
            txtAccHolder.Text = "";
            txtBranch.Text = "";
            txtSIFSC.Text = "";
            txtSCountry.Text = "";
            txtRAccNo.Text = "";
            txtRAccHolder.Text = "";
            txtRBankName.Text = "";
            txtRBranch.Text = "";
            txtRCountry.Text = "";
            txtRIFSC.Text = "";
        }

        protected void btnAddNewBank_Click(object sender, EventArgs e)
        {
            grdSavings.Visible = false;
            btnAddNewBank.Visible = false;
            pnlForm.Visible = true;
            grdReimburse.Visible = false;
            ltrSavings.Visible = false;
            ltrReminburse.Visible = false;
            btnSubmit.Visible = true;
            bool value = Proxy.GetBankDetailsById(Convert.ToInt32(Request.QueryString["EmpId"]));
            if (value)
            {
                GetBankDetails(Convert.ToInt32(Request.QueryString["EmpId"]));
            }
        }

        public void GetBankDetails(int empid)
        {
            DataSet ds = new DataSet();
            ds = Proxy.GetBankById(empid);

            DataSet dsRA = new DataSet();
            dsRA = Proxy.GetReimburseBankById(empid);

            txtAccNo.Text = ds.Tables[0].Rows[0][2].ToString();
            txtAccHolder.Text = ds.Tables[0].Rows[0][5].ToString();
            txtBankName.Text = ds.Tables[0].Rows[0][1].ToString();
            txtBranch.Text = ds.Tables[0].Rows[0][6].ToString();
            txtSCountry.Text = ds.Tables[0].Rows[0][3].ToString();
            txtSIFSC.Text = ds.Tables[0].Rows[0][4].ToString();
            txtRAccHolder.Text = dsRA.Tables[0].Rows[0][5].ToString();
            txtRAccNo.Text = dsRA.Tables[0].Rows[0][2].ToString();
            txtRBankName.Text = dsRA.Tables[0].Rows[0][1].ToString();
            txtRBranch.Text = dsRA.Tables[0].Rows[0][6].ToString();
            txtRCountry.Text = dsRA.Tables[0].Rows[0][3].ToString();
            txtRIFSC.Text = dsRA.Tables[0].Rows[0][4].ToString();

        }
    }
}