﻿using HRMDAL.Entites;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace HRMDAL.Repositries
{
    public class DailyAttendRepsitry : BaseRepositry
    {
        public void DailyAttendance(Entites.DailyAttendance Atten)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand();
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.CommandText = "SPDailyAttendance";
                        da.SelectCommand.Connection = con;

                        da.SelectCommand.Parameters.AddWithValue("@empid", Atten.EmpID);
                        da.SelectCommand.Parameters.AddWithValue("@empname", Atten.EmpName);
                        da.SelectCommand.Parameters.AddWithValue("@date", Atten.Date);
                        da.SelectCommand.Parameters.AddWithValue("@intime", Atten.InTime);
                        da.SelectCommand.Parameters.AddWithValue("@outtime", Atten.OutTime);
                        da.SelectCommand.Parameters.AddWithValue("@leave", Atten.Leave);
                        da.SelectCommand.ExecuteNonQuery();

                    }
                }
            }
            catch
            {
                throw;
            }
        }

        public void ApplyOnDuty(ApplyOnDuty ApplyOnDuty)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "SPApplyOnDuty";
                        cmd.Connection = con;
                        
                        cmd.Parameters.Add(new SqlParameter("@EmpID", ApplyOnDuty.EmpID));
                        cmd.Parameters.Add(new SqlParameter("@FromDate", ApplyOnDuty.FromDate));
                        cmd.Parameters.Add(new SqlParameter("@ToDate", ApplyOnDuty.ToDate));
                        cmd.Parameters.Add(new SqlParameter("@TypeOf", ApplyOnDuty.TypeOf));
                        cmd.Parameters.Add(new SqlParameter("@Reason", ApplyOnDuty.Reason));
                        cmd.Parameters.Add(new SqlParameter("@RmID", ApplyOnDuty.RmID));
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        public DataSet GetOnDutyHistory(int empId)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand();
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.CommandText = "GetONDutyHistory";
                        da.SelectCommand.Parameters.AddWithValue("@empId", empId);
                        da.SelectCommand.Connection = con;

                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        public DataSet GetAttendanceRecord(int empId, DateTime startdate, DateTime enddate)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();

                   string start = startdate.ToString("dd-MM-yyyy");
                   string end = enddate.ToString("dd-MM-yyyy");

                   string query = "select * from AttendanceDetails WHERE f3 BETWEEN '" + start + "' AND '" + end + "' and f1 = '" + empId + "'";

                    using (SqlDataAdapter da = new SqlDataAdapter(query, con))
                    {
                        da.SelectCommand.Connection = con;

                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        public string GetApproverByID(int empid)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();

                    string query = "select ReportingManager from EmployeeMaster where EmployeeId='"+empid+"'";

                    using (SqlCommand cmd = new SqlCommand(query,con))
                    {
                        string result = cmd.ExecuteScalar().ToString();
                        return result;
                    }
                }
            }
            catch 
            {                
                throw;
            }
        }

        public DataSet GetNIOCategory()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();

                    string query = "select NIOType from NotInOfficeMaster";

                    using (SqlDataAdapter da = new SqlDataAdapter(query, con))
                    {
                        da.SelectCommand.Connection = con;
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        public DataSet GetLeaveTypes()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();

                    string query = "select LeaveID,LeaveType from LeaveTypeMaster";

                    using (SqlDataAdapter da = new SqlDataAdapter(query, con))
                    {
                        da.SelectCommand.Connection = con;
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

    }
}
