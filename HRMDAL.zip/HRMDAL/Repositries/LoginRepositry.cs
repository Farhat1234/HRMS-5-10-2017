﻿using System.Data.SqlClient;
using System.Data;
using HRMDAL.Entites;

namespace HRMDAL.Repositries
{
    public class LoginRepositry : BaseRepositry
    {
        public bool LoginRep(int empID, string password)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();
                    using (SqlDataAdapter cmd = new SqlDataAdapter())
                    {
                        cmd.SelectCommand = new SqlCommand();
                        cmd.SelectCommand.CommandType = CommandType.StoredProcedure;
                        cmd.SelectCommand.CommandText = "SPCheckUserExists";
                        cmd.SelectCommand.Connection = con;

                        cmd.SelectCommand.Parameters.AddWithValue("@EmpID", empID);
                        cmd.SelectCommand.Parameters.AddWithValue("@pass", password);
                        var result = cmd.SelectCommand.ExecuteScalar();

                        if (result == null)
                        {
                            return false;
                        }

                        return true;

                    }

                }

            }
            catch
            {
                throw;
            }
        }

        public void AddCredentials(int empid, string password)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand();
                        da.SelectCommand.Connection = con;
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.CommandText = "SPLogin";

                        da.SelectCommand.Parameters.AddWithValue("@EmpID", empid);
                        da.SelectCommand.Parameters.AddWithValue("@Password", password);
                        da.SelectCommand.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        public Login GetRoleByUserId(int empid, string password)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(HRMConString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "SPGetRoleID";
                        cmd.Connection = con;

                        SqlParameter prm = new SqlParameter();

                        prm = cmd.Parameters.Add("@paswd", SqlDbType.NVarChar, 50);
                        prm.Direction = ParameterDirection.Input;
                        prm.Value = password;

                        prm = cmd.Parameters.Add("@EmpID", SqlDbType.Int);
                        prm.Direction = ParameterDirection.Input;
                        prm.Value = empid;

                        prm = cmd.Parameters.Add("@roleid", SqlDbType.Int);
                        prm.Direction = ParameterDirection.Output;
                        
                        cmd.ExecuteScalar();
                        Entites.Login login = new Entites.Login();
                        login.RoleID = (int)cmd.Parameters["@roleid"].Value == null ? 0 : (int)cmd.Parameters["@roleid"].Value;                                              

                        con.Close();
                        return login;
                    }

                }

            }
            catch
            {
                throw;
            }
        }
    }
}
