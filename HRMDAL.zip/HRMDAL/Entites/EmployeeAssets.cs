﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HRMDAL.Entites
{
    public class EmployeeAssets
    {
        public int EmpId { get; set; }

        public string TypeOfAsset { get; set; }

        public DateTime IssuedDate { get; set; }

        public DateTime ReturnedDate { get; set; }

        public string AssetDetails { get; set; }
    }
}
